// import React from "react";
// import {  Route,Navigate } from "react-router-dom";

// const PrivateRoute = ({ component: Component, path, ...rest }) => {
//   const accessToken = localStorage.getItem("token");
//   return (
//     <Route
//       {...rest}
//       path={path}
//       render={(props) =>
//         accessToken && accessToken !== "" ? (
//           <Component {...props} />
//         ) : (
//         //   <Redirect to="/" />
//         <Navigate to='/' />
//         )
//       }
//     />
//   );
// };
// export default PrivateRoute;

import React from 'react'
import { Navigate } from 'react-router-dom'
// import { useAuth } from '../../context/AuthContext'

export default function PrivateRoute({ children }) {
    const accessToken = localStorage.getItem("token");

  if (!accessToken) {
    return <Navigate to='/' />
  }

  return children;
}
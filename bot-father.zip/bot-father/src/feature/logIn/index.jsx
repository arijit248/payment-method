import { useState,useCallback,useEffect } from "react";
import { useDispatch,useSelector, } from "react-redux";
// import { increment, decrement } from "./slice";
import { loginData } from "./slice";
import { useLocation,useNavigate  } from "react-router-dom";
import Input from "../../component/InputField";
import Paper from "@material-ui/core/Paper";
import Grid from "@material-ui/core/Grid";
import Button from "../../component/ButtonField";
import Heading from "../../component/HeadingField";
import "./index.css";
// import LoginImg from "../../assets/login1.svg";
import LoginImg from "../../assets/login3.svg";
const Login = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const history = useNavigate()
  // const prices = useSelector((state) => state.loginSlice.prices.data);
  // const loading = useSelector((state) => state.loginSlice.loading);
  const [email,setEmail] = useState("")
  const [password,setPassword] = useState("")
  const error = useSelector((state) => state.loginSlice.isError)
  const loggedIn = useSelector((state) => state.loginSlice.loggedIn)
  // useEffect(() => {
  //   if (!loading) {
  //     dispatch(getData());
  //   }
  // }, []);

  // const handleLoginData = useCallback((e,p)=>{
  //   if(e!=undefined&&p!=undefined){
  //     const logInDetails = {
  //       username:e,
  //       password:p
  //     }
  //     dispatch(loginData(logInDetails));
  //   // console.log(e,"btncomp",p);
  //   }
  // },[])

  const handleLoginData = () => {
    const logInDetails = {
            username:email,
            password:password
          }
          console.log(logInDetails)
          dispatch(loginData(logInDetails));
  }

  useEffect(() => {
if(loggedIn){
  history('/home')
}
  },[loggedIn])

  return (
    <div>
      <div className="background">
        {error !== ''?<p>{error}</p>:null }
        <Grid container>
          <Grid item xs={12} md={8} lg={8} className="leftGrid">
            {/* <h1 className="imageHeading">Hi, Welcome back</h1> */}
            <img src={LoginImg} alt="login image" className="leftImage" />
          </Grid>
          <Grid item xs={12} md={4} lg={4}>
            {/* <Paper className=""> */}
            <Paper elevation={6} className="loginPaper">
              {/* position: "relative", */}
              <div className="loginField">
                <Heading />
                <Input className="inputPaper" label="Email" valueEmail={email} type="email" changeEmail={(e)=>setEmail(e.target.value)} />
                <Input className="inputPaper" label="Password" valuePassWord={password} type="password" changePassword={(e)=>setPassword(e.target.value)} />
                <div className="btnBlockDiv">
                  <Button onClickLogin={()=>handleLoginData(email,password)}  />
                </div>
              </div>
            </Paper>
            {/* </Paper> */}
            {/* {console.log(prices)} */}
          </Grid>
        </Grid>
      </div>
    </div>
  );
};

export default Login;

import { call, put, takeLatest } from "redux-saga/effects";
import { fetchData } from "../../utils/helper/fetch";
import { loginSuccess,loginErrorData,loginData } from "./slice";

function* get_login_data(payload) {
  console.log(payload,"qwerty");
  const request = {
    email: payload.payload.username,
    password:payload.payload.password
  }
  console.log(request)
  try {
    const response = yield call(
      fetchData,
      "http://ec2-13-235-150-170.ap-south-1.compute.amazonaws.com/login",{
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(request)
      }
    );
    // console.log(response, "saga");
    if (response?.status === 200) {
      console.log(response?.data?.token);
      localStorage.setItem("token",response?.data?.token);
      localStorage.setItem("username",response?.data?.username);
      yield put(loginSuccess(response?.data));
    }else{
      const error = Array.isArray(response?.data?.data)?response?.data?.data[0]?.msg:response?.data?.data;
      console.log(error,"error")
      yield put(loginErrorData(error))
    }
  } catch (err) {
    console.log(err,"catch");
    // yield put(loginErrorData(err))
  }
}
export default function* loginSaga() {
  yield takeLatest(loginData.type, get_login_data);

}

import { createSlice } from "@reduxjs/toolkit";

export const initialState = {
  counter: 0,
  login: [],
  loading: false,
  loggedIn:false,
  isError:"",
};

const rootReducer = createSlice({
  name: "loginSlice",
  initialState,
  reducers: {
    increment: (state) => {
      state.counter += 1;
    },
    decrement: (state) => {
      state.counter -= 1;
    },
    // getData: (state) => {
    //   return {
    //     ...state,
    //     loading: true,
    //   };
    // },
    loginData: (state, action) => {
      return{
        ...state,
        loading:true
      }
    },
    loginSuccess : (state,action) => {
      return {
        ...state,
        login: action.payload,
        loggedIn:true,
        loading: false,
    }
  },
    loginErrorData: (state, action) => {
      return {
        ...state,
        isError: action.payload,
      };
    },
  },
});

export const { increment, decrement, loginData,loginErrorData,loginSuccess } = rootReducer.actions;
export default rootReducer.reducer;

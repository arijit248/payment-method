import "../common.css";
const Contact = () => {
  return (
    <div
      className="commonStyles"
      // style={{
      //   background:
      //     "linear-gradient(133deg,rgb(103 58 183 / 100%) 4%,rgb(247 247 247 / 90%) 51%)top center / cover no-repeat",
      // }}
    >
      <h1>Contact</h1>
    </div>
  );
};
export default Contact;

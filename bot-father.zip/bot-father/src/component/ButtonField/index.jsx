import Button from "@material-ui/core/Button";
import PropTypes from "prop-types";
import "./index.css";

export default function ContainedButtons({onClickLogin}) {
  return (
    <div className="btnContainer">
      <Button variant="contained" color="secondary" className="btnBlock" onClick={onClickLogin}  > 
      {/* //onClick={onClickLogin} */}
        Login
      </Button>
    </div>
  );
}

ContainedButtons.propTypes = {
  onClickLogin: PropTypes.func,
};

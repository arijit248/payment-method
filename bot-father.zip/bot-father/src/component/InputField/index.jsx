import TextField from "@material-ui/core/TextField";
import PropTypes from "prop-types";
import "./index.css";
export default function BasicTextFields({ className, label,valueEmail,valuePassWord,type,changeEmail,changePassword }) {
  // console.log(valueEmail,valuePassWord,"srdtfyukjl")
  return (
    <TextField
      id="outlined-basic"
      label={label}
      variant="outlined"
      className={className}
      value={type == "email"? valueEmail : type == "password" ? valuePassWord : null}
      onChange={type == "email"? changeEmail : type == "password" ? changePassword : null}
    />
  );
}

BasicTextFields.propTypes = {
  className: PropTypes.string,
  label: PropTypes.string,
  valueEmail:PropTypes.any,
  valuePassWord:PropTypes.any,
  type:PropTypes.string,
  changeEmail:PropTypes.func,
  changePassword:PropTypes.func,
};
